<?php

session_start();

if (@$_SESSION['adminLogin']=="success") {
    header("location:dashboard.php");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Registration </title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <style type="text/css">
       #eye_icon{
        position:absolute;
        top:32px;
        right:2px;
       }
     </style>
   </head>
<body>
  <div class="container">
    <div class="title">Registration</div>
    <div class="content">
      <form action="login_insert.php" method="POST">
        <div class="user-details">
          
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" name="email" placeholder="Enter your email" autofocus="on">
          </div>
          
          <div class="input-box" style="position : relative;">
            <span class="details">Password</span>
            <input type="password" name="password" placeholder="Enter your password" class="show_hide">
            <img src="all_image/eye_icon.png" id="eye_icon">
          </div>
         
        </div>
       
        <div class="button">
          <input type="submit" name="submit" value="Register">
        </div>
      </form>
    </div>
  </div>

</body>
</html>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script> 
<script>  
$(document).ready(function(){  
    $("#eye_icon").click(function(){  
      
      var show_hide =$(".show_hide");
      if(show_hide.attr('type')==='password')
        {
          show_hide.attr('type','text');
      }else{
         show_hide.attr('type','password');
      }
  
    });  
});

</script>  



