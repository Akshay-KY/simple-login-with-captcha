<?php 

require_once "connection.php";


if(isset($_POST['submit'])){

	$email=$_POST['email'];
	$password=md5($_POST['password']);

	$sql = mysqli_query($conn, "SELECT * from login WHERE email='$email' AND password='$password'");
       
    
    if(mysqli_fetch_assoc($sql)){
        $_SESSION['adminLogin'] = "success";
        header("location:dashboard.php");
    }
    else{
        header("location:index.php");
    }
}


?>